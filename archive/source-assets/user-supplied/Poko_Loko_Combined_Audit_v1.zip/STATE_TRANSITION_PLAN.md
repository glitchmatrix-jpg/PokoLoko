# State Transition Plan

See `COMBINED_AUDIT.md`, section 7.

The redesign must use an event-driven authoritative state machine. Stable states, transition states, events, guards, animation-completion events, and locomotion-completion events must be explicit. React must not infer transitions from previous IPC values.

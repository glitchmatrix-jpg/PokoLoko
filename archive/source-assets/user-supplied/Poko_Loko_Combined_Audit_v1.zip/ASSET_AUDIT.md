# Asset Audit

See `COMBINED_AUDIT.md`, sections 2, 4, 8, and 9.

## Decision summary

- Freeze `Poko_Loko_Asset_Pack_v1` unchanged as the authoritative source pack.
- Build a separate curated runtime pack.
- Approve only core idle, locomotion, and sleep sequences first.
- Review the 14 Poko manual-review flags in an animation lab.
- Do not promote the 218 isolated poses automatically.
- Do not assume matching behavior coverage between Poko and Loko.

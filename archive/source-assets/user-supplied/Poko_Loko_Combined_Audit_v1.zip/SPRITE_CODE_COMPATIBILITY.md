# Sprite–Code Compatibility

See `COMBINED_AUDIT.md`, section 4.

The new asset pack is not a one-to-one replacement for the old 24 required animation groups. It should drive a new character-specific state graph rather than be flattened into the existing generic states.

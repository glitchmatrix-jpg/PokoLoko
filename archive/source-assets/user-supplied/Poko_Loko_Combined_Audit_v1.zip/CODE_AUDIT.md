# Code Audit

See `COMBINED_AUDIT.md`, sections 3, 4, 6, 7, and 10.

## Decision summary

Preserve Electron/React/TypeScript, security, store, tray concept, work-area helpers, packaging, and build workflows. Replace the pet runtime, state model, animation integration, renderer, locomotion, interactions, settings UI, and old asset manifest.

# Poko Loko — Combined Asset-Pack and Codebase Audit

**Audit date:** 5 August 2026  
**Inputs reviewed:** `Poko_Loko_Asset_Pack_v1.zip` and `PokoLoko-main.zip`  
**Conclusion:** The asset pack is a strong archival and normalization result, but the current program should not be incrementally polished. Keep the Electron shell and build tooling; redesign the product, interaction model, renderer, animation runtime, locomotion engine, behavior system, settings experience, and visual language.

---

## 1. Executive verdict

The current app is not merely visually unfinished. Its product model is too small for the asset library and too rigid to make either character feel alive.

The current program treats a pet as:

- one transparent 180 × 180 Electron window;
- one 128 × 128 image centered at the bottom;
- eight coarse states;
- one random behavior timer;
- one walking interval;
- two click reactions;
- a basic tray and settings form.

The new pack instead contains:

- 406 accepted source candidates;
- 223 frames organized into 31 normalized animations;
- 218 retained isolated poses;
- 128 × 128 shared normalized canvases;
- explicit anchors, movement metadata, confidence, transitions, and known issues;
- source-index maps, contact sheets, QA reports, registries, and developer utilities.

The mismatch is architectural. The existing app cannot make meaningful use of the pack without flattening its metadata and reintroducing the same visual and behavioral problems.

### Recommendation

**Full product redesign with selective infrastructure reuse.**

Keep:

- Electron, React, TypeScript, and Vite;
- the secure preload/context-isolation model;
- the tray concept;
- persistent settings storage;
- Windows work-area and multi-monitor primitives;
- installer and GitHub Actions configuration.

Replace or substantially redesign:

- pet window composition;
- sprite/animation registry integration;
- renderer architecture;
- state machine;
- behavior planner;
- locomotion and turn logic;
- drag/drop physics and reactions;
- settings UI;
- tray presentation and identity;
- visual scale and shadow treatment;
- all old runtime assets and `animations.json`.

---

## 2. Asset-pack audit

### 2.1 Verified strengths

The package is unusually thorough for a first-pass sprite extraction project.

- Both source sheets are preserved unchanged with checksums.
- All runtime frames use a shared transparent 128 × 128 canvas.
- All 223 animation frames passed PNG, alpha, canvas, nonblank, boundary, opaque-background, fringe, and declared-resampling checks.
- No accepted source candidate was discarded.
- There are no missing referenced frames or JSON parse failures in the final validation.
- Two directional animations were mirrored conservatively and marked as generated.
- Numerical anchors and movement metadata are present.
- Confidence and known-issue fields are preserved rather than hidden.

This is good asset governance. The pack is suitable as the authoritative source library.

### 2.2 Important distinction: 406 accepted frames vs 223 animation frames

The package contains 406 accepted source candidates, but only 223 are currently organized into 31 runtime-ready sequences. The remaining 218 are isolated poses retained for later classification or one-shot use.

That means the program should not attempt to expose “all sprites” as autonomous behaviors. The isolated poses are a visual archive, not a finished behavior library.

### 2.3 Animation inventory

#### Poko — 14 sequences

- `poko_idle_blink` — 2 frames, high confidence
- `poko_idle_look_01` — 2 frames, high confidence
- `poko_locomotion_side` — 9 frames, medium confidence
- `poko_walk_right` — 9 frames, medium confidence
- `poko_walk_left` — mirrored, 9 frames, medium confidence
- `poko_sleep_transition` — 8 frames, high confidence
- `poko_sleep_loop_01` — 7 frames, high confidence; ping-pong recommended
- `poko_sleep_loop_02` — 4 frames, high confidence
- `poko_drink` — 8 frames, high confidence
- `poko_eat` — 11 frames, medium confidence; possible abrupt pair
- `poko_music` — 12 frames, high confidence
- `poko_peeking` — 12 frames, medium confidence; possible abrupt pair
- `poko_playing_ball` — 11 frames, high confidence; several intentional-looking metric jumps
- `poko_sad_to_crying` — 8 frames, high confidence

#### Loko — 17 sequences

- `loko_idle_front` — 8 frames, high confidence
- `loko_locomotion_side_01` — 3 frames, medium confidence
- `loko_locomotion_side_02` — 7 frames, medium confidence
- `loko_walk_preparation` — 3 frames, medium confidence
- `loko_walk_right` — 7 frames, medium confidence
- `loko_walk_left` — mirrored, 7 frames, medium confidence
- `loko_sleep_transition` — 6 frames, high confidence
- `loko_sleep_loop` — 3 frames, high confidence
- `loko_drink_02` — 7 frames, high confidence
- `loko_eat` — 9 frames, high confidence
- `loko_laptop` — 12 frames, medium confidence; possible abrupt pair
- `loko_music` — 11 frames, high confidence
- `loko_peeking_01` — 3 frames, high confidence
- `loko_peeking_02` — 5 frames, high confidence
- `loko_playing_ball_01` — 7 frames, high confidence
- `loko_reading_01` — 5 frames, high confidence
- `loko_love_reaction` — 8 frames, medium confidence; possible abrupt pair

### 2.4 Manual-review flags

There are 14 conservative QA flags. All are in two Poko sequences:

- `poko_peeking`: one body-width and one centroid jump between frames 4 and 5.
- `poko_playing_ball`: twelve area, width, height, and centroid changes across several adjacent pairs.

These flags do not prove extraction errors. The ball sequence contains large intentional pose changes, so numerical outliers are expected. However, these animations should be reviewed in a runtime animation lab before production use.

### 2.5 Asset-pack limitations that affect the redesign

1. **No independent props/effects library.** Props remain composite because safe separation was uncertain. Runtime layering, prop persistence, and reusable object interactions are therefore not yet available.
2. **No complete posture system.** There are sleep transitions and loops, but no consistently documented stand-to-sit, sit-idle, sit-to-stand, or wake sequence for both characters.
3. **Locomotion confidence is medium.** The walking assets are usable candidates, but must be tuned against actual movement speed and inspected for foot sliding.
4. **Asymmetric character coverage.** Poko and Loko do not have matching activity sets. The product must embrace character-specific behavior rather than force identical menus.
5. **Short idle libraries.** Poko’s two-frame blink/look sequences cannot alone create a rich idle state. Loko has a stronger eight-frame idle.
6. **Isolated poses are not transitions.** The archive may contain useful bridge poses, but they require a second semantic curation pass before entering a state graph.
7. **Anchor metadata is animation-level.** The current metadata provides stable anchors, but a sophisticated renderer may eventually need per-frame body/contact anchors for high-precision interactions.

### 2.6 Asset status decision

The pack should be frozen as:

`Poko_Loko_Asset_Pack_v1.0.0 — authoritative archival and normalized source`

Do not overwrite it during implementation. Create a separate curated runtime package, for example:

`Poko_Loko_Runtime_Assets_v0.2/`

That runtime package should include only approved sequences, optimized manifests, and any manually curated transition subsets.

---

## 3. Codebase audit

### 3.1 Overall structure

The repository is small and legible:

- Electron main process in one `electron/main.ts` file;
- one preload bridge;
- a JSON-file settings store;
- React renderer with `Pet`, `Sprite`, and `Settings` components;
- one `useSpriteAnimation` hook;
- one flat stylesheet;
- one old `public/assets/animations.json` registry;
- a simple PNG existence/dimension validator.

This simplicity made the prototype easy to build, but it is now the main constraint.

### 3.2 What is technically sound

- `contextIsolation: true`, `nodeIntegration: false`, and `sandbox: true` are good defaults.
- External navigation and window creation are denied.
- The app uses a single-instance lock.
- Settings writes use a temporary file and rename pattern.
- Work-area bounds account for the taskbar.
- Dragging supports multiple displays.
- Asset URLs are package-safe rather than development-only absolute paths.
- Walking uses elapsed time rather than a fixed number of pixels per interval.
- `requestAnimationFrame` drives sprite playback.
- The build scripts separate renderer and Electron compilation.

These are worth preserving.

### 3.3 Critical architectural problems

#### A. The main process owns behavior, while the renderer secretly owns transition logic

The main process sends coarse states such as `SLEEPING`. The renderer then guesses whether to show `sleep_transition`, `sleep_loop`, or `wake` based on its locally remembered previous state.

This creates two competing state machines:

- authoritative behavior state in Electron;
- implicit visual state in React.

They can drift apart. For example, the main process can schedule a new behavior before a non-looping animation has finished. The renderer’s `next` field changes only its local animation name and never informs the main process that a transition completed.

#### B. Timers are behavior, not a state machine

`chooseBehavior()` randomly sets `IDLE`, starts walking, sets `SITTING`, sets `SLEEPING`, or triggers a reaction. There are no guarded transitions, entry/exit actions, interruption rules, or transition completion events.

The current model cannot express:

- stop walking gracefully;
- turn before reversing direction;
- sit down before sitting;
- wake before walking;
- cancel an activity safely;
- hold a prop consistently;
- resume a prior state after interaction;
- queue behavior after an animation completes.

#### C. Walking ends with a snap to idle

The app chooses a random destination, moves the entire window, then immediately changes to `IDLE`. There is no deceleration, stopping sequence, foot-phase-aware finish, direction-preserving side idle, or turn state.

The random destination model also produces purposeless motion rather than believable wandering.

#### D. The current asset model throws away the new pack’s value

The old `AnimationDef` supports only:

- fps;
- loop;
- next;
- literal `'bottom-center'` anchor;
- frame paths.

It cannot represent:

- numerical anchors;
- movement metadata;
- confidence;
- known issues;
- transition-from/to constraints;
- playback mode such as ping-pong;
- mirrored provenance;
- state category;
- recommended speed;
- interaction anchors;
- per-character scale policies.

#### E. The window and sprite coordinate systems are conflated

The window is 180 × 180. The sprite is 128 × 128, flex-aligned to the bottom center with four pixels of padding. Electron movement is based on the full 180-pixel window, not the actual sprite’s ground anchor or visible footprint.

Consequences:

- screen-edge behavior is based on invisible window padding;
- the pet appears to stop before reaching the real edge;
- floor alignment is the window bottom, not the character’s foot/contact anchor;
- wider effects and different poses cannot be positioned precisely;
- hit testing covers the entire transparent stage, not the visible character.

#### F. Rendering uses generic CSS instead of metadata

`object-fit: contain` and `object-position: center bottom` make every image obey the same geometric rule. The new pack was normalized to avoid that exact simplification.

The CSS drop shadow and synthetic pink hit glow are also applied universally, regardless of pose, activity, sleep state, or art direction.

#### G. Interaction model is shallow and occasionally conflicting

- Single click is delayed to distinguish double click.
- Four clicks within 1.4 seconds trigger only `confused`.
- Double click opens settings.
- Dragging begins after six pixels.
- The whole 180 × 180 transparent rectangle is interactive.

There is no visible feedback for hover, press, pickup, carrying, annoyance, trust, or cooldown. The click model encourages spam rather than relationship.

#### H. Pause semantics are inaccurate

The settings text says autonomous movement stops while interactions remain active. Internally, pausing forces `IDLE`, clears transitions, and can interrupt sleep or another state abruptly. A paused pet should settle into a valid stable visual state rather than being reset.

#### I. Character identity is mostly numeric

Poko and Loko differ only in speed, idle timer range, and sleep weight. Their behavior vocabularies, decision logic, interaction responses, and movement styles are otherwise identical.

This wastes the distinct asset sets.

#### J. The settings experience looks like a developer utility

The settings window is a generic form with two pet buttons and two checkboxes. It does not communicate character identity, preview animations, scale, movement preferences, sleep behavior, interaction controls, accessibility, startup behavior, or personality.

It also labels Poko with a cat emoji and Loko with a rabbit emoji, which is visually inconsistent with the custom pixel-art identity.

### 3.4 Validation gaps

The old validator checks only:

- required animation names;
- positive FPS;
- frame existence;
- PNG signature;
- dimensions within each animation.

It does not validate:

- alpha transparency;
- canvas consistency across the character;
- missing manifest targets;
- anchor ranges;
- transition graph validity;
- loop seam quality;
- duplicate frames;
- asset preload failures;
- registry/schema conformance;
- packaged runtime load behavior;
- visual scale or ground jitter.

The new pack’s validation is far stronger and should replace this script as the basis for runtime QA.

### 3.5 Documentation overclaims

The README and `IMPLEMENTATION.json` describe a “state-machine,” “autonomous movement,” and validated application. In reality, the behavior model is a random timer scheduler with coarse states. The wording should be corrected during the redesign so documentation reflects actual capabilities.

---

## 4. Code-to-asset compatibility

| Existing runtime state | Current animation | New asset candidates | Compatibility | Decision |
|---|---|---|---|---|
| `IDLE` | old `idle` | `poko_idle_blink`, `poko_idle_look_01`, `loko_idle_front` | Partial | Replace with layered idle planner |
| `WALKING_LEFT` | old `walk_left` | `poko_walk_left`, `loko_walk_left` | Good candidate | Rebuild locomotion around metadata |
| `WALKING_RIGHT` | old `walk_right` | `poko_walk_right`, `loko_walk_right` | Good candidate | Rebuild locomotion around metadata |
| `SITTING` | old `sit` | no clearly matched normalized core sequence for both | Poor | Remove from v0.2 core unless isolated poses are curated |
| `SLEEPING` | old transition + loop | Poko and Loko sleep transitions/loops | Strong | Rebuild as explicit transition chain |
| `DRAGGED` | old `dragged` | no normalized dragged sequence in the 31 animations | Missing | Use curated isolated pose or temporary stable pickup pose |
| `LANDING` | old `landing` | no normalized landing sequence in the 31 animations | Missing | Redesign drop behavior; do not fake with unrelated frames |
| `INTERACTING` | `happy`/`confused` | Poko sad/crying; Loko love; several activities | Concept mismatch | Replace with named reaction/activity states |
| click happy | old `happy` | no direct normalized equivalent for both | Missing | Character-specific response or subtle idle reaction |
| click confused | old `confused` | no direct normalized equivalent for both | Missing | Do not carry forward as universal response |

### Key compatibility conclusion

The new pack does **not** provide a one-for-one replacement for the old 24 required animation groups. That is a good reason to redesign rather than mechanically swap folders.

The old program requires generic symmetric assets. The new pack is richer but character-specific. The new product should be designed around what each character actually has.

---

## 5. Product and visual redesign direction

### 5.1 New product thesis

Poko Loko should feel like two tiny creatures sharing the desktop, not a GIF player moving a transparent browser window.

The product should prioritize:

- believable presence;
- smooth movement and grounding;
- rare but meaningful actions;
- character-specific habits;
- responsive interactions;
- calm, unobtrusive autonomy;
- coherent pixel-art presentation;
- a settings experience with identity.

### 5.2 Visual system

Recommended direction:

- transparent stage with no permanent synthetic glow;
- optional soft pixel-compatible contact shadow derived from state;
- exact 128 × 128 sprite layer positioned by anchors;
- larger invisible stage only where needed for hit testing and effects;
- state-aware hit mask based on alpha or visible-body bounds;
- no interpolation, CSS transforms that create blur, or arbitrary scaling;
- consistent logical display scale controlled in settings, e.g. 1×, 1.5×, 2× using integer/nearest-neighbor strategy where possible;
- custom Poko/Loko icons and labels, no emoji stand-ins;
- settings UI using the characters’ real art and live previews.

### 5.3 New settings experience

The settings app should be redesigned as a polished companion panel with:

- live pet preview;
- character cards for Poko and Loko;
- size control;
- movement frequency;
- calm/active behavior mode;
- sleep permission and quiet hours;
- interaction sensitivity;
- always-on-top;
- launch at startup;
- monitor preference;
- sound toggle reserved for future use;
- reset position;
- diagnostics/developer mode.

### 5.4 Character-specific identity

Poko and Loko should not run the same weighted table.

Example direction:

**Poko**
- quicker locomotion;
- more glances and short walks;
- music, ball, peek, and emotional sequences;
- shorter rests;
- more reactive to clicks.

**Loko**
- slower movement;
- longer idle and sleep periods;
- reading, laptop, eating, drinking, and music;
- calmer reactions;
- longer activity holds.

---

## 6. Proposed architecture

```text
src/
  app/
    PetApp.tsx
    SettingsApp.tsx
  pet/
    domain/
      petState.ts
      petEvents.ts
      petConfig.ts
      transitionGraph.ts
    runtime/
      PetRuntime.ts
      StateMachine.ts
      BehaviorPlanner.ts
      LocomotionController.ts
      AnimationController.ts
      InteractionController.ts
      ActivityController.ts
    assets/
      runtimeManifest.ts
      assetResolver.ts
      schemas.ts
      selectors.ts
    renderer/
      PetStage.tsx
      SpriteLayer.tsx
      ShadowLayer.tsx
      DebugOverlay.tsx
    settings/
      SettingsShell.tsx
      CharacterPreview.tsx
      BehaviorControls.tsx

electron/
  main.ts
  windows/
    createPetWindow.ts
    createSettingsWindow.ts
  pet/
    WindowMotionBridge.ts
    ScreenService.ts
    PositionStore.ts
  ipc/
    channels.ts
    handlers.ts
  store/
    settingsStore.ts
```

### Ownership rules

- **State machine:** owns the authoritative state and legal transitions.
- **Animation controller:** owns frame playback and emits completion/loop events.
- **Behavior planner:** proposes actions only from stable states.
- **Locomotion controller:** owns position, velocity, destination, direction, and stopping.
- **Electron main process:** owns native window position and system integration.
- **Renderer:** draws the exact state supplied; it does not infer hidden transitions.
- **Asset registry:** is data-driven and schema-validated.

---

## 7. Proposed state model

### Stable states

- `idle_front`
- `idle_side`
- `walking`
- `sleeping`
- `activity`
- `held`
- `paused`

### Transition states

- `prepare_walk`
- `turning`
- `stopping`
- `sleep_transition`
- `waking`
- `pickup`
- `drop`
- `activity_enter`
- `activity_exit`
- `character_swap`

### Events

- `behavior_timeout`
- `animation_complete`
- `destination_reached`
- `screen_edge_near`
- `pointer_press`
- `drag_started`
- `drag_moved`
- `drag_released`
- `pet_clicked`
- `settings_changed`
- `display_changed`
- `pause_requested`
- `resume_requested`

A transition should occur because of an event and a guard, not because two unrelated timers happened to expire.

---

## 8. Curated runtime scope for the first redesigned build

The first redesigned build should prove quality, not quantity.

### Poko v0.2 approved candidates

- idle micro-loop assembled from `poko_idle_blink` and `poko_idle_look_01` with neutral holds;
- `poko_walk_right`;
- `poko_walk_left`;
- `poko_sleep_transition`;
- one selected Poko sleep loop after runtime seam testing;
- `poko_music` as the first optional activity;
- `poko_sad_to_crying` only as a deliberately rare reaction, not click spam.

### Loko v0.2 approved candidates

- `loko_idle_front`;
- `loko_walk_preparation`;
- `loko_walk_right`;
- `loko_walk_left`;
- `loko_sleep_transition`;
- `loko_sleep_loop`;
- `loko_reading_01` as the first optional activity;
- `loko_love_reaction` only after visual review.

### Defer

- both peeking families;
- ball activities;
- Poko eating;
- Loko laptop;
- generic sitting until transition coverage is curated;
- pickup/landing until suitable isolated poses are selected;
- reusable props/effects until separation is safe.

---

## 9. Acceptance criteria for the redesign

### Visual

- No opaque or checkerboard backgrounds.
- No visible scaling change between idle and walking.
- Ground anchor changes by no more than one display pixel during ordinary locomotion.
- No frame clipping at all supported display scales.
- No blur at 100%, 150%, or 200% Windows scaling.
- No universal glow that makes the art look pasted onto the desktop.

### Animation

- Every non-looping animation emits exactly one completion event.
- Loop seams are approved visually or use declared ping-pong playback.
- Transitions never jump directly from sleep to walk or activity to walk.
- Animation phase and locomotion speed do not produce obvious foot sliding.

### Movement

- Position uses a monotonic delta-time loop.
- The pet turns or stops before reversing direction.
- Visible body bounds, not just window bounds, are used near screen edges.
- Multi-monitor transitions preserve floor alignment.
- Taskbar and work-area changes do not strand the pet off-screen.

### Interaction

- Click, double-click, and drag do not conflict.
- The transparent empty area does not behave like a giant invisible button.
- Drag release routes through a valid visual state.
- Repeated clicking has cooldowns and does not encourage frantic spam.

### Product

- Poko and Loko behave differently.
- Settings changes do not reset the pet abruptly.
- Pause settles the pet into a stable state.
- The app can run for at least one hour without state drift, timer leaks, or stuck behavior.

---

## 10. Implementation sequence

1. Freeze both uploaded ZIPs and create a new redesign branch.
2. Build a runtime asset curator that imports the v1 pack without modifying it.
3. Create JSON schema validation for the new runtime manifest.
4. Build a standalone animation lab with frame stepping, anchor overlays, loop preview, and speed controls.
5. Approve the core Poko and Loko idle/walk/sleep sequences.
6. Replace the renderer with anchor-aware layers.
7. Introduce the authoritative event-driven state machine.
8. Replace `setInterval` window motion with a dedicated locomotion controller and high-resolution timing.
9. Add turn/stop routing and body-aware screen bounds.
10. Rebuild pointer hit testing, pickup, and drop behavior.
11. Redesign settings and tray identity.
12. Add one character-specific activity per pet.
13. Add long-run diagnostics and automated state-transition tests.
14. Package and test on Windows at multiple scaling levels and monitors.

---

## 11. Final decision

The current repository is a useful prototype scaffold, not a product foundation in its present shape.

A “sprite replacement” patch would fail because:

- the current state vocabulary does not match the new assets;
- visual transitions are inferred in React rather than governed centrally;
- anchor metadata would be discarded;
- character identity would remain shallow;
- interactions and settings would still feel cheap;
- movement would still look procedural rather than alive.

The right move is a **full redesign of the experience and pet engine**, while preserving only the secure Electron shell, storage, packaging, and selected native-window utilities.

# Implementation Plan

See `COMBINED_AUDIT.md`, sections 6, 8, 9, and 10.

The first milestone is an animation lab and curated runtime manifest, followed by anchor-aware rendering, event-driven state management, locomotion, interactions, and a complete settings redesign.
